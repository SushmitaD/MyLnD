function fb() {
    var b= 1;
    console.log(b);
    
}

function fa() {
    var a = 2;
    console.log(a);
    fb();
}

var c=3;
console.log(c);
fa();
fb();